package com.example.StockMarket.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.StockMarket.model.Company;
import com.example.StockMarket.service.CompanyService;




@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/StockMarket")
public class AdminController {
	
	@Autowired
	CompanyService adminservice;
	
	@GetMapping("/companies")
	public List<Company> getAllCustomers() {
		System.out.println("Get all Customers...");

		List<Company> customers = new ArrayList<>();
		adminservice.findAll().forEach(customers::add);

		return customers;

}
}