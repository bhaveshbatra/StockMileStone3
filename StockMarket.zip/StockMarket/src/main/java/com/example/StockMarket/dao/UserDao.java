package com.example.StockMarket.dao;

public class UserDao {

}
