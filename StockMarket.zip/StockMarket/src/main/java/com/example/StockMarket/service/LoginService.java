package com.example.StockMarket.service;

import org.springframework.data.repository.CrudRepository;

import com.example.StockMarket.model.User;



public interface LoginService extends CrudRepository<User, Long>{

}
