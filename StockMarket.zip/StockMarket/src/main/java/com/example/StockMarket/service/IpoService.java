package com.example.StockMarket.service;

import org.springframework.data.repository.CrudRepository;

import com.example.StockMarket.model.IpoPlanned;



public interface IpoService extends CrudRepository<IpoPlanned, Long>{

}