package com.example.StockMarket.dao;

public class CompanyDao {

}
