package com.example.StockMarket.service;



import org.springframework.data.repository.CrudRepository;


import com.example.StockMarket.model.User;



public interface UserService  extends CrudRepository<User, Long>{

	

}

